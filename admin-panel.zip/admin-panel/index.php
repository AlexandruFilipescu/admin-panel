<?php
/*
    Plugin Name: Admin Panel
    Plugin URI: http://filipescu.ml
    Author: Filipescu Alexandru, a passionate web enthusiast.
    Author URI: http://filipescu.ml
    Description: Generates a custom Admin panel based on what cars are inserted.
*/


add_action('admin_menu','bc_admin_meniu');

function bc_admin_meniu() {
    add_menu_page(
        'Pagina de setări tabel',
        'Reservations table',
        'manage_options',
        'admin_number/index.php',
        'bc_admin_page_content',
        'dashicons-visibility',
        11
    );
}

function bc_admin_page_content() {

    $db_admin_number = get_option('admin_number');

    echo '<div class="wrap">';
    echo '<h2>Reservations table</h2>'
   
?>
<?php

global $wpdb;

$user = $wpdb->get_results(" SELECT * FROM  `tabel_clienti`");

?>

<script src="https://code.jquery.com/jquery-1.12.4.min.js?ver=4.9.8"></script>
<style>
.buton-trei {
    background-color: #c90f0f !important;
    border-color: #cf0a0a #c70909 #c70909 !important;
    box-shadow: 0 1px 0 #c70909 !important;
    color: #fff !important;
    text-decoration: none !important;
    text-shadow: 0 -1px 1px #c70909, 1px 0 1px #c70909, 0 1px 1px #c70909, -1px 0 1px #c70909 !important;
    
}</style>

<table class="widefat fixed striped" cellspacing="0">
    <thead>
   
    <tr>
            <th id="columnname" class="manage-column column-columnname" scope="col">ID</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Title</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Complete name</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Date of rental</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Departure date</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Phone number</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Email</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Car Reserved</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Number of days</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Price</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Total Price</th>
            <th id="columnname" class="manage-column column-columnname" scope="col">Order Status</th>
            
    </tr>
    </thead>


    <tbody >
    <?php foreach($user as $row) { ?>
        <tr id="<?php echo $row->id ?>">
            <th class="column-columnname"><?php echo $row->id; ?></th>
            <td class="column-columnname"><?php echo $row->titlu; ?></td>
            <td class="column-columnname"><?php echo $row->nume; ?></td>
            <td class="column-columnname"><?php echo $row->data_inchiriere; ?></td>
            <td class="column-columnname"><?php echo $row->data_plecare; ?></td>
            <td class="column-columnname"><?php echo $row->telefon; ?></td>
            <td class="column-columnname"><?php echo $row->email; ?></td>
            <td class="column-columnname"><?php echo $row->masina; ?></td>
            <td class="column-columnname"><?php echo $row->zile; ?></td>
            <td class="column-columnname"><?php echo $row->pret; ?>€</td>
            <td class="column-columnname"><?php echo $row->pret_total; ?>€</td>
            <td class="column-columnname">

            <select name="default_role" class="selector" id="<?php echo $row->id;?>">
                <option value="Unattended"  <?php if ($row->stare_comanda == "Unattended") {echo 'selected="selected" ';} ?>>Unattended </option>
                <option value="Under approval" <?php if ($row->stare_comanda == "Under approval") {echo 'selected="selected" ';} ?>>Under approval </option>
                <option value="Completed" <?php if ($row->stare_comanda == "Completed") {echo 'selected="selected" ';} ?>>Completed</option>
            </select> </td>

            <td type="hidden" class="column-columnname" id="<?php echo $row->id;?>"></td>
            <td class="column-columnname" id="<?php echo $row->id;?>">
            <button id="<?php echo $row->id;?>" class="button buton-trei">Delete</button>
            </td>
        </tr>
        <?php } ?>
    </tbody>
  
    <tfoot>
    </tfoot>

</table>

<script>

$(".selector").change(function(){

    $ce_am_ales = $(this).val();
    $id_ales = $(this).attr('id');
    console.log($ce_am_ales);
    console.log($id_ales);

$.ajax({
    type: "POST",
    url: "<?php echo plugin_dir_url(__FILE__) . 'update.php' ; ?>",
    data: {
     ales: $ce_am_ales ,
     id: $id_ales
    },
    success: function(){
        $('.good-boy').fadeIn('200').delay('1000').fadeOut('200');
    }
   
});
});

$(".buton-trei").click(function(){
  $sterge = $(this).attr('id');
  $sterge_vizual = $(this);
  $.ajax({
      type: "POST",
      url: "<?php echo plugin_dir_url(__FILE__) . 'update.php'; ?>",
      data: {
          sterge: $sterge
      },
      success: function(){
        $sterge_vizual.parent().parent().fadeOut('200');
        $('.good-boy').fadeIn('200').delay('1000').fadeOut('200');
      }
  });
});



</script>



<?php
echo '<center><img style="width:40px; border-radius:50%; margin-top:10px; display:none;" class="good-boy" src="https://autosib.filipescu.ml/wp-content/uploads/2018/09/585d0331234507.564a1d239ac5e.gif"></center>';
echo '</div>';

?>
<?php
}
?>
<?php






