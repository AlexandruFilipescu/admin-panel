<?php


// echo $path . '/wpthemes5/wp-includes/wp-db.php';

include_once  '../../../wp-config.php';
include_once  '../../../wp-load.php';
include_once  '../../../wp-includes/wp-db.php';



global $wpdb;

$ales = $_POST['ales'];
$id = $_POST['id'];
$sterge = $_POST['sterge'];
// echo $ales;
// echo $id;
// echo $sterge;

$wpdb->update('tabel_clienti',
    array(
        'stare_comanda' => $ales
    ),
    array(
        'ID' => $id
    ),
    array(
        '%s'
    )

);


$wpdb->delete('tabel_clienti',
  array(
      'ID' => $sterge
  )
);


